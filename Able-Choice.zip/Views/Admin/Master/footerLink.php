<script src="../../Assets/Vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="../../Assets/Vendor/aos/aos.js"></script>
  <script src="../../Assets/Vendor/glightbox/js/glightbox.min.js"></script>
  <script src="../../Assets/Vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="../../Assets/Vendor/swiper/swiper-bundle.min.js"></script>
  <script src="../../Assets/Vendor/purecounter/purecounter_vanilla.js"></script>
  <script src="../../Assets/Vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="../../Assets/Script/main.js"></script>