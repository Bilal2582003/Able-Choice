<!-- ======= Breadcrumbs ======= -->
<div class="breadcrumbs d-flex align-items-center" style="background-image: url('../../Assets/Images/breadcrumbs-bg-1.webp');">
  <div class="container position-relative d-flex flex-column align-items-center" data-aos="fade">

    <h2><?php echo $page?></h2>
    <ol>
      <li><a href="Index.php">Home</a></li>
      <li><?php echo $page?></li>
    </ol>

  </div>
</div><!-- End Breadcrumbs -->