  <!-- Favicons -->
  <link href="../Assets/Images/favicon.png" rel="icon">
  <link href="../Assets/Images/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,600;1,700&family=Roboto:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&family=Work+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&display=swap" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="../Assets/Vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="../Assets/Vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="../Assets/Vendor/fontawesome-free/css/all.min.css" rel="stylesheet">
  <link href="../Assets/Vendor/aos/aos.css" rel="stylesheet">
  <link href="../Assets/Vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="../Assets/Vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
  <!-- <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script> -->
  <script src="../Assets/Vendor/jquery/jquery.min.js"></script>

  <!-- Template Main CSS File -->
  <link href="../Assets/Style/main.css" rel="stylesheet">