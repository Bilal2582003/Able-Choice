<!-- Vendor JS Files (Deferred) -->
<script src="../Assets/Vendor/bootstrap/js/bootstrap.bundle.min.js" defer></script>
<script src="../Assets/Vendor/aos/aos.js" defer></script>
<script src="../Assets/Vendor/glightbox/js/glightbox.min.js" defer></script>
<script src="../Assets/Vendor/isotope-layout/isotope.pkgd.min.js" defer></script>
<script src="../Assets/Vendor/swiper/swiper-bundle.min.js" defer></script>
<script src="../Assets/Vendor/purecounter/purecounter_vanilla.js" defer></script>
<script src="../Assets/Vendor/php-email-form/validate.js" defer></script>

<!-- Template Main JS File -->
<script src="../Assets/Script/main.js" ></script>
