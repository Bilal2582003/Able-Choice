<script>
    window.location.assign('Views/Index.php')
</script>